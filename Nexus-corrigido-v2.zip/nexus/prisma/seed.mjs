import { PrismaClient } from '@prisma/client'
const prisma=new PrismaClient()
const plans=[['start','Nexo Start',30000,30,['Acesso ao acompanhamento de mercado','Atualizações do ciclo'],['Garantia de capital','Rendimento fixo']],['core','Nexo Core',90000,60,['Acesso ao acompanhamento de mercado','Atualizações do ciclo','Leitura de contexto'],['Garantia de capital','Rendimento fixo']],['prime','Nexo Prime',250000,90,['Acesso ao acompanhamento de mercado','Atualizações do ciclo','Leitura de contexto aprofundada'],['Garantia de capital','Rendimento fixo']]]
for(const [id,name,minimum,horizonDays,included,excluded] of plans) await prisma.plan.upsert({where:{id},update:{name,minimum,horizonDays,included,excluded},create:{id,name,minimum,horizonDays,included,excluded}})
await prisma.$disconnect()
