import Link from "next/link"
import { Header, Footer, SectionIntro, Ticker } from "@/components/site-shell"
import { CopyField } from "@/components/copy-field"
import { payments, plans, formatAOA } from "@/lib/site-data"
import { requireSession } from "@/lib/auth"
import { createDepositAction } from "@/app/deposit-actions"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, CheckCircle2 } from "lucide-react"

export default async function Depositar({ searchParams }: { searchParams: Promise<{ plano?: string; erro?: string }> }) {
  const session = await requireSession()
  const params = await searchParams
  const plan = plans.find((item) => item.id === params.plano)
  const paymentReady = Boolean(payments.multicaixa.entidade || payments.kwik.iban)
  return <><Ticker/><Header/><main className="page-wrap"><div className="container"><SectionIntro eyebrow="NEXUS / DEPOSITAR" title="Como entrar no seu plano.">Escolha um ciclo, faça o pagamento pelos dados configurados e envie o comprovativo. A confirmação só acontece depois de reconciliação.</SectionIntro>
    {!paymentReady && <div className="risk-banner mt-8"><AlertTriangle className="shrink-0 text-champagne"/><p>Os dados de pagamento ainda não estão configurados. Não faça um pagamento até esta página indicar uma entidade ou IBAN válidos.</p></div>}
    <div className="mt-12 grid gap-5 lg:grid-cols-2">
      <Card><CardHeader><p className="eyebrow">MÉTODO 01</p><CardTitle className="mt-2 text-2xl">Multicaixa — Pagamento por Referência</CardTitle></CardHeader><CardContent>{payments.multicaixa.entidade ? <CopyField label="Entidade" value={payments.multicaixa.entidade}/> : <p className="text-sm text-muted-foreground">Dados de pagamento ainda não configurados.</p>}<ol className="mt-7 flex flex-col gap-4 text-sm leading-6 text-muted-foreground">{["Abra Multicaixa, Express ou homebanking", "Escolha Pagamentos por Referência", "Introduza a entidade e o valor do plano", "Guarde o talão da operação"].map((x,i)=><li key={x} className="flex gap-3"><span className="font-mono text-champagne">0{i+1}</span>{x}</li>)}</ol></CardContent></Card>
      <Card><CardHeader><p className="eyebrow">MÉTODO 02</p><CardTitle className="mt-2 text-2xl">KWiK</CardTitle></CardHeader><CardContent>{payments.kwik.iban ? <CopyField label="IBAN KWiK" value={payments.kwik.iban}/> : <p className="text-sm text-muted-foreground">Dados de pagamento ainda não configurados.</p>}<p className="mt-5 text-sm text-muted-foreground">Para transferências KWiK. Contacto de suporte: <span className="font-mono text-foreground">{payments.mozambique}</span>.</p></CardContent></Card>
    </div>
    {plan ? <Card className="mt-8"><CardHeader><p className="eyebrow">CICLO SELECCIONADO</p><CardTitle className="mt-2 text-2xl">{plan.name} · {formatAOA(plan.minimum)} · {plan.horizon}</CardTitle></CardHeader><CardContent><form action={createDepositAction} className="grid gap-5 md:grid-cols-2"><input type="hidden" name="planId" value={plan.id}/><input type="hidden" name="amount" value={plan.minimum}/><label className="grid gap-2 text-sm">Método<select name="method" required className="h-11 rounded-md border border-border bg-background px-3"><option value="multicaixa">Multicaixa</option><option value="kwik">KWiK / M-Pesa / e-Mola</option></select></label><label className="grid gap-2 text-sm">Data do pagamento<input name="paidAt" type="date" required className="h-11 rounded-md border border-border bg-background px-3"/></label><label className="grid gap-2 text-sm md:col-span-2">Referência do talão<input name="receiptReference" required placeholder="Referência visível no comprovativo" className="h-11 rounded-md border border-border bg-background px-3"/></label><label className="grid gap-2 text-sm md:col-span-2">Comprovativo (JPG, PNG ou PDF, máx. 5 MB)<input name="receipt" type="file" accept="image/jpeg,image/png,application/pdf" required className="rounded-md border border-border bg-background px-3 py-3"/></label><button type="submit" className="button md:col-span-2">Enviar comprovativo</button></form><p className="mt-5 text-xs text-muted-foreground">O depósito ficará em revisão até ser reconciliado. Não pedimos PIN, OTP, SMS ou seed phrase.</p></CardContent></Card> : <div className="mt-8 rounded-lg border border-border p-6"><p className="text-sm text-muted-foreground">Escolha um plano antes de iniciar um depósito.</p><Link className="mt-4 inline-block text-sm text-teal" href="/planos">Ver planos</Link></div>}
  </div></main><Footer/></>
}

export const dynamic = "force-dynamic"
