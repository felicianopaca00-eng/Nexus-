"use server"

import { put } from "@vercel/blob"
import { randomBytes } from "crypto"
import { redirect } from "next/navigation"
import { prisma } from "@/lib/prisma"
import { requireSession } from "@/lib/auth"
import { auditLog } from "@/lib/audit"
import { sendEmail, depositReceivedEmail } from "@/lib/email"
import { formatAOA } from "@/lib/plan-data"

export async function createDepositAction(formData: FormData) {
  const session = await requireSession()
  const planId = String(formData.get("planId") || "")
  const method = String(formData.get("method") || "")
  const amount = Number(formData.get("amount"))
  const paidAtValue = String(formData.get("paidAt") || "")
  const receiptReference = String(formData.get("receiptReference") || "").trim()
  const file = formData.get("receipt")
  const plan = await prisma.plan.findUnique({ where: { id: planId } })
  const methodConfigured = method === "multicaixa"
    ? Boolean(process.env.PAYMENT_ENTITY)
    : method === "kwik"
      ? Boolean(process.env.PAYMENT_IBAN_KWIK)
      : false
  if (!plan || !methodConfigured || amount !== plan.minimum || !paidAtValue || !receiptReference) {
    redirect(`/depositar?plano=${planId}&erro=dados`)
  }
  let receiptPathname: string | undefined
  if (file instanceof File && file.size > 0) {
    if (file.size > 5 * 1024 * 1024 || !["image/jpeg", "image/png", "application/pdf"].includes(file.type)) {
      redirect(`/depositar?plano=${planId}&erro=ficheiro`)
    }
    const blob = await put(`receipts/${session.userId}/${randomBytes(12).toString("hex")}-${file.name}`, file, { access: "private", contentType: file.type })
    receiptPathname = blob.pathname
  }
  const participation = await prisma.participation.create({ data: { userId: session.userId, planId: plan.id, amount: plan.minimum, status: "aguarda_pagamento" } })
  const deposit = await prisma.deposit.create({
    data: {
      userId: session.userId,
      participationId: participation.id,
      method,
      amount,
      paymentReference: `NX-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`,
      receiptReference,
      receiptPathname,
      paidAt: new Date(paidAtValue),
      status: "em_revisao",
    },
  })
  await auditLog({ userId: session.userId, action: "deposit_submitted", entity: "Deposit", entityId: deposit.id, meta: { amount, method, planId } })
  const mail = depositReceivedEmail(session.user.name, formatAOA(amount), plan.name)
  await sendEmail(session.user.email, mail.subject, mail.html)
  redirect("/painel?deposito=enviado")
}

export async function startParticipationAction(formData: FormData) {
  await requireSession()
  redirect(`/depositar?plano=${String(formData.get("planId") || "")}`)
}
