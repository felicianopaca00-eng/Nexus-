"use server"
import { redirect } from "next/navigation"
import { prisma } from "@/lib/prisma"
import { createSession, hashPassword, verifyPassword, revokeSession, resetHash } from "@/lib/auth"
import { loginSchema, registerSchema } from "@/lib/validation"
import { rateLimit } from "@/lib/rate-limit"
import { auditLog } from "@/lib/audit"
import { sendEmail, passwordResetEmail } from "@/lib/email"
import { randomBytes } from "crypto"

function safeNext(value: FormDataEntryValue | null) {
  const next = typeof value === "string" ? value : ""
  return next.startsWith("/") && !next.startsWith("//") ? next : "/painel"
}

export async function registerAction(_: unknown, formData: FormData) {
  const ip = "unknown" // In real edge, pass from headers if available
  const limit = rateLimit(`reg:${ip}`, 5, 15 * 60 * 1000)
  if (!limit.ok) return { error: "Demasiadas tentativas. Tenta de novo em alguns minutos." }

  const parsed = registerSchema.safeParse(Object.fromEntries(formData))
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Dados inválidos." }
  const { name, email, password } = parsed.data
  const exists = await prisma.user.findUnique({ where: { email } })
  if (exists) return { error: "Não foi possível criar a conta com estes dados." }
  const user = await prisma.user.create({ data: { name, email, passwordHash: await hashPassword(password) } })
  await createSession(user.id)
  await auditLog({ userId: user.id, action: "register", entity: "User", entityId: user.id })
  redirect(safeNext(formData.get("next")))
}

export async function loginAction(_: unknown, formData: FormData) {
  const ip = "unknown"
  const limit = rateLimit(`login:${ip}`, 5, 15 * 60 * 1000)
  if (!limit.ok) return { error: "Demasiadas tentativas. Tenta de novo em alguns minutos." }

  const parsed = loginSchema.safeParse(Object.fromEntries(formData))
  if (!parsed.success) return { error: "Email ou palavra-passe inválidos." }
  const user = await prisma.user.findUnique({ where: { email: parsed.data.email } })
  if (!user || !(await verifyPassword(parsed.data.password, user.passwordHash))) {
    await auditLog({ action: "login_failed", meta: { email: parsed.data.email } })
    return { error: "Email ou palavra-passe inválidos." }
  }
  await createSession(user.id)
  await auditLog({ userId: user.id, action: "login", entity: "User", entityId: user.id })
  redirect(safeNext(formData.get("next")))
}

export async function logoutAction() {
  await revokeSession()
  redirect("/")
}

export async function requestPasswordResetAction(_: unknown, formData: FormData) {
  const email = String(formData.get("email") || "").trim().toLowerCase()
  if (!email || !email.includes("@")) return { error: "Indica um email válido." }

  const limit = rateLimit(`reset:${email}`, 3, 60 * 60 * 1000)
  if (!limit.ok) return { ok: true } // silent

  const user = await prisma.user.findUnique({ where: { email } })
  if (user) {
    const token = randomBytes(32).toString("hex")
    const tokenHash = resetHash(token)
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000)
    await prisma.passwordResetToken.create({ data: { email, tokenHash, expiresAt } })
    const mail = passwordResetEmail(user.name, token)
    await sendEmail(user.email, mail.subject, mail.html)
    await auditLog({ userId: user.id, action: "password_reset_requested" })
  }
  return { ok: true }
}

export async function resetPasswordAction(_: unknown, formData: FormData) {
  const token = String(formData.get("token") || "")
  const password = String(formData.get("password") || "")
  const confirmation = String(formData.get("confirmation") || "")
  if (password.length < 8) return { error: "A palavra-passe deve ter pelo menos 8 caracteres." }
  if (password !== confirmation) return { error: "As palavras-passe não coincidem." }

  const tokenHash = resetHash(token)
  const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash } })
  if (!record || record.usedAt || record.expiresAt < new Date()) return { error: "Link inválido ou expirado." }

  const user = await prisma.user.findUnique({ where: { email: record.email } })
  if (!user) return { error: "Conta não encontrada." }

  await prisma.user.update({ where: { id: user.id }, data: { passwordHash: await hashPassword(password) } })
  await prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } })
  await prisma.session.updateMany({ where: { userId: user.id }, data: { revokedAt: new Date() } })
  await auditLog({ userId: user.id, action: "password_reset_completed" })
  return { ok: true }
}
