import Link from "next/link"
import { ArrowUpRight, BarChart3, Bell, CircleHelp, FileText, Gift, LockKeyhole, Settings, Wallet } from "lucide-react"
import { Header, UserBottomNav } from "@/components/site-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { requireSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { formatAOA } from "@/lib/plan-data"
import { logoutAction } from "@/app/auth-actions"

const modules = [
  { href: "/planos", label: "Planos de investimento", detail: "Compare planos e simule retornos", icon: BarChart3 },
  { href: "/depositar", label: "Depósitos", detail: "Referências, comprovativos e estados", icon: Wallet },
  { href: "/perfil", label: "Perfil e segurança", detail: "Dados, sessões e preferências", icon: LockKeyhole },
]

export default async function Painel() {
  const session = await requireSession()
  const participation = await prisma.participation.findFirst({ where: { userId: session.userId, status: { in: ["aguarda_pagamento", "em_revisao", "confirmado"] } }, include: { plan: true, deposits: { orderBy: { createdAt: "desc" } } }, orderBy: { createdAt: "desc" } })
  const confirmed = participation?.deposits.filter((deposit) => deposit.status === "confirmado").reduce((sum, deposit) => sum + deposit.amount, 0) ?? 0
  const active = Boolean(participation?.status === "confirmado")

  return <><Header /><main className="page-wrap pb-28"><div className="container">
    <div className="flex flex-wrap items-start justify-between gap-5"><div><p className="eyebrow">NEXUS / ÁREA DO UTILIZADOR</p><h1 className="mt-3 font-heading text-4xl">Olá, {session.user.name}.</h1><p className="mt-2 text-sm text-muted-foreground">Acompanhe o seu património e as suas operações num só lugar.</p></div><form action={logoutAction}><Button variant="outline" type="submit">Terminar sessão</Button></form></div>
    <section className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Resumo financeiro"><Card><CardHeader><p className="eyebrow">SALDO TOTAL</p><CardTitle className="mt-2">{formatAOA(confirmed)}</CardTitle></CardHeader><CardContent><p className="text-xs text-muted-foreground">Disponível + investido</p></CardContent></Card><Card><CardHeader><p className="eyebrow">DISPONÍVEL</p><CardTitle className="mt-2">{formatAOA(confirmed)}</CardTitle></CardHeader><CardContent><p className="text-xs text-muted-foreground">Saldo confirmado</p></CardContent></Card><Card><CardHeader><p className="eyebrow">LUCROS ACUMULADOS</p><CardTitle className="mt-2">0 Kz</CardTitle></CardHeader><CardContent><p className="text-xs text-muted-foreground">Sem retornos lançados</p></CardContent></Card><Card><CardHeader><p className="eyebrow">INVESTIMENTOS</p><CardTitle className="mt-2">{active ? "1 ativo" : "0 ativos"}</CardTitle></CardHeader><CardContent><p className="text-xs text-muted-foreground">Estado da sua carteira</p></CardContent></Card></section>
    <div className="mt-8 grid gap-5 lg:grid-cols-[1.4fr_.8fr]"><Card><CardHeader className="flex flex-row items-center justify-between"><div><p className="eyebrow">EVOLUÇÃO</p><CardTitle className="mt-2">Visão geral do investimento</CardTitle></div><Badge variant={active ? "default" : "secondary"}>{active ? "Ativo" : "A aguardar"}</Badge></CardHeader><CardContent>{participation ? <div className="grid gap-6 sm:grid-cols-2"><div><p className="text-sm text-muted-foreground">Plano atual</p><p className="mt-1 text-lg font-medium">{participation.plan.name}</p><p className="mt-1 text-sm text-muted-foreground">{formatAOA(participation.amount)} · {participation.plan.horizonDays} dias</p></div><div><p className="text-sm text-muted-foreground">Próximo vencimento</p><p className="mt-1 text-lg font-medium">A confirmar</p><p className="mt-1 text-sm text-muted-foreground">Será calculado após a confirmação</p></div></div> : <div className="flex flex-col items-start gap-4"><p className="text-sm leading-6 text-muted-foreground">Ainda não tem investimentos ativos. Escolha um plano para começar.</p><Button asChild><Link href="/planos">Ver planos <ArrowUpRight data-icon="inline-end" /></Link></Button></div>}</CardContent></Card><Card><CardHeader><CardTitle>Atalhos rápidos</CardTitle></CardHeader><CardContent className="grid gap-3">{modules.map(({ href, label, icon: Icon }) => <Button key={href} asChild variant="outline" className="justify-start"><Link href={href}><Icon data-icon="inline-start" />{label}</Link></Button>)}</CardContent></Card></div>
    <section className="mt-8"><div className="mb-4 flex items-center justify-between"><div><p className="eyebrow">CENTRO DA CONTA</p><h2 className="mt-2 font-heading text-2xl">Tudo o que precisa, organizado</h2></div><Bell className="text-champagne" /></div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[{ label: "Histórico e extrato", href: "/extrato" }, { label: "Indicações e missões", href: "/indicacoes" }, { label: "Notificações", href: "/notificacoes" }, { label: "Suporte e FAQ", href: "/suporte" }, { label: "Carteira", href: "/carteira" }, { label: "Configurações", href: "/configuracoes" }, { label: "Termos e políticas", href: "/termos-conta" }, { label: "Ranking e conquistas", href: "/ranking" }].map(({ label, href }, index) => { const icons = [FileText, Gift, Bell, CircleHelp, Wallet, Settings, FileText, BarChart3]; const Icon = icons[index]; return <Link key={label} href={href}><Card className="transition-colors hover:border-primary/60"><CardContent className="flex items-center gap-3 p-5"><Icon className="text-champagne" /><div><p className="font-medium">{label}</p><p className="mt-1 text-xs text-muted-foreground">Abrir área</p></div></CardContent></Card></Link> })}</div></section>
  </div></main><UserBottomNav /></>
}
