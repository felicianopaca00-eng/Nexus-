"use client"

import { useActionState } from "react"
import { Header, Footer, SectionIntro, Ticker } from "@/components/site-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { contactAction } from "@/app/contact-actions"

export default function Contacto() {
  const [state, action, pending] = useActionState(contactAction, null)
  return (
    <>
      <Ticker />
      <Header />
      <main className="page-wrap">
        <div className="container max-w-xl">
          <SectionIntro eyebrow="NEXUS / CONTACTO" title="Fala connosco.">
            Dúvidas sobre planos, depósitos ou acesso. Respondemos o mais depressa possível.
          </SectionIntro>
          <Card className="mt-10">
            <CardHeader>
              <CardTitle>Enviar mensagem</CardTitle>
            </CardHeader>
            <CardContent>
              {state?.ok ? (
                <p className="text-sm text-teal">Mensagem recebida. Vamos responder em breve.</p>
              ) : (
                <form action={action} className="flex flex-col gap-5">
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="name">Nome</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" name="email" type="email" required />
                  </div>
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="subject">Assunto</Label>
                    <Input id="subject" name="subject" required />
                  </div>
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="message">Mensagem</Label>
                    <textarea id="message" name="message" required minLength={10} className="min-h-28 rounded-md border border-border bg-background px-3 py-2 text-sm" />
                  </div>
                  {state?.error && <p className="text-sm text-red-400">{state.error}</p>}
                  <Button type="submit" disabled={pending}>{pending ? "A enviar…" : "Enviar"}</Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </>
  )
}
