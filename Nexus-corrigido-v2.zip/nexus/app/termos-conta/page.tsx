import { AccountRoute } from "@/components/account-page"
export default function Page() { return <AccountRoute type="termos" /> }
