"use server"

import { prisma } from "@/lib/prisma"
import { contactSchema } from "@/lib/validation"
import { getSession } from "@/lib/auth"
import { auditLog } from "@/lib/audit"
import { sendEmail } from "@/lib/email"

export async function contactAction(_: unknown, formData: FormData) {
  const parsed = contactSchema.safeParse(Object.fromEntries(formData))
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Dados inválidos." }
  const { name, email, subject, message } = parsed.data
  const session = await getSession()
  await prisma.contactMessage.create({
    data: { name, email, subject, message, userId: session?.userId ?? null },
  })
  await auditLog({ userId: session?.userId, action: "contact_message", meta: { subject } })
  await sendEmail(email, "Mensagem recebida — Nexus Investments", `<p>Olá, ${name}. Recebemos a tua mensagem sobre "${subject}".</p>`)
  return { ok: true }
}
