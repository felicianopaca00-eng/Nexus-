"use client"

import Link from "next/link"
import { useActionState, useSearchParams } from "react"
import { Header } from "@/components/site-shell"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { requestPasswordResetAction, resetPasswordAction } from "@/app/auth-actions"
import { Suspense } from "react"

function RecuperarForm() {
  const searchParams = useSearchParams()
  const token = searchParams.get("token")
  const [reqState, reqAction, reqPending] = useActionState(requestPasswordResetAction, null)
  const [resetState, resetAction, resetPending] = useActionState(resetPasswordAction, null)

  if (token) {
    if (resetState?.ok) {
      return (
        <div className="flex flex-col gap-5">
          <p className="text-sm text-teal">Palavra-passe redefinida. Já podes entrar.</p>
          <Button asChild><Link href="/entrar">Ir para o login</Link></Button>
        </div>
      )
    }
    return (
      <form action={resetAction} className="flex flex-col gap-5">
        <input type="hidden" name="token" value={token} />
        <div className="flex flex-col gap-2">
          <Label htmlFor="password">Nova palavra-passe</Label>
          <Input id="password" name="password" type="password" minLength={8} required />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="confirmation">Confirmar</Label>
          <Input id="confirmation" name="confirmation" type="password" minLength={8} required />
        </div>
        {resetState?.error && <p className="text-sm text-red-400">{resetState.error}</p>}
        <Button type="submit" disabled={resetPending}>{resetPending ? "A guardar…" : "Definir nova palavra-passe"}</Button>
      </form>
    )
  }

  if (reqState?.ok) {
    return (
      <div className="flex flex-col gap-5">
        <p className="text-sm leading-6 text-muted-foreground">Se existir uma conta com este email, enviámos as instruções. Verifica a caixa de entrada.</p>
        <Button asChild><Link href="/entrar">Voltar ao acesso</Link></Button>
      </div>
    )
  }

  return (
    <form action={reqAction} className="flex flex-col gap-5">
      <div className="flex flex-col gap-2">
        <Label htmlFor="email">Email da conta</Label>
        <Input id="email" name="email" type="email" required />
      </div>
      {reqState?.error && <p className="text-sm text-red-400">{reqState.error}</p>}
      <Button type="submit" disabled={reqPending}>{reqPending ? "A enviar…" : "Enviar instruções"}</Button>
    </form>
  )
}

export default function RecuperarPage() {
  return (
    <>
      <Header />
      <main className="auth-shell">
        <Card className="auth-card">
          <CardHeader>
            <p className="eyebrow">NEXUS / SEGURANÇA</p>
            <CardTitle className="mt-2 text-3xl">Recuperar palavra-passe</CardTitle>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<p className="text-sm text-muted-foreground">A carregar…</p>}>
              <RecuperarForm />
            </Suspense>
            <div className="mt-6 flex justify-between text-sm">
              <Link className="text-teal hover:underline" href="/entrar">Voltar ao login</Link>
              <Link className="text-teal hover:underline" href="/registar">Criar conta</Link>
            </div>
          </CardContent>
        </Card>
      </main>
    </>
  )
}
