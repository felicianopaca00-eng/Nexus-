"use server"

import { revalidatePath } from "next/cache"
import { prisma } from "@/lib/prisma"
import { requireAdmin } from "@/lib/admin"
import { auditLog } from "@/lib/audit"
import { sendEmail, depositStatusEmail } from "@/lib/email"
import { formatAOA } from "@/lib/plan-data"

export async function reviewDepositAction(depositId: string, decision: "confirmado" | "rejeitado", note?: string) {
  const admin = await requireAdmin()
  if (!admin) return { error: "Sem permissão." }

  const deposit = await prisma.deposit.findUnique({ where: { id: depositId }, include: { user: true, participation: { include: { plan: true } } } })
  if (!deposit) return { error: "Depósito não encontrado." }

  const now = new Date()
  await prisma.deposit.update({
    where: { id: depositId },
    data: { status: decision, adminNote: note || null, reviewedAt: now },
  })

  if (decision === "confirmado") {
    await prisma.participation.update({
      where: { id: deposit.participationId },
      data: { status: "confirmado", confirmedAt: now },
    })
  }

  await auditLog({
    userId: admin.userId,
    action: `deposit_${decision}`,
    entity: "Deposit",
    entityId: depositId,
    meta: { note, amount: deposit.amount },
  })

  const mail = depositStatusEmail(deposit.user.name, formatAOA(deposit.amount), decision, note)
  await sendEmail(deposit.user.email, mail.subject, mail.html)

  revalidatePath("/admin")
  return { ok: true }
}
