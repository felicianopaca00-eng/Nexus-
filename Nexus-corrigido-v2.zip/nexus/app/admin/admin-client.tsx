"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { AdminHeader, AdminShell } from "@/components/admin-shell"
import { reviewDepositAction } from "@/app/admin-actions"
import { formatAOA } from "@/lib/plan-data"
import { toast } from "sonner"

type Props = {
  users: any[]
  deposits: any[]
  participations: any[]
  messages: any[]
  logs: any[]
}

export default function AdminClient({ users, deposits, participations, messages, logs }: Props) {
  const [section, setSection] = useState("overview")
  const pending = deposits.filter((d) => d.status === "em_revisao")

  async function review(id: string, decision: "confirmado" | "rejeitado") {
    const res = await reviewDepositAction(id, decision)
    if (res?.ok) toast.success(decision === "confirmado" ? "Confirmado" : "Rejeitado")
    else toast.error(res?.error || "Erro")
  }

  return (
    <AdminShell>
      <div className="p-4 md:p-0">
        <AdminHeader title="Administração" description="Operação real. Ações gravam na base de dados." />
        <div className="mb-6 flex gap-2 overflow-x-auto">
          {["overview", "deposits", "users", "messages", "logs"].map((s) => (
            <Button key={s} size="sm" variant={section === s ? "secondary" : "ghost"} onClick={() => setSection(s)}>
              {s}
            </Button>
          ))}
        </div>

        {section === "overview" && (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">Utilizadores</p><p className="mt-2 text-2xl">{users.length}</p></CardContent></Card>
            <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">Depósitos pendentes</p><p className="mt-2 text-2xl">{pending.length}</p></CardContent></Card>
            <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">Participações</p><p className="mt-2 text-2xl">{participations.length}</p></CardContent></Card>
            <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">Mensagens</p><p className="mt-2 text-2xl">{messages.length}</p></CardContent></Card>
          </div>
        )}

        {section === "deposits" && (
          <Card>
            <CardHeader><CardTitle>Depósitos</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Utilizador</TableHead><TableHead>Plano</TableHead><TableHead>Valor</TableHead><TableHead>Estado</TableHead><TableHead>Ações</TableHead></TableRow></TableHeader>
                <TableBody>
                  {deposits.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell>{d.user?.name}<div className="text-xs text-muted-foreground">{d.user?.email}</div></TableCell>
                      <TableCell>{d.participation?.plan?.name}</TableCell>
                      <TableCell>{formatAOA(d.amount)}</TableCell>
                      <TableCell><Badge variant="outline">{d.status}</Badge></TableCell>
                      <TableCell>
                        {d.status === "em_revisao" && (
                          <div className="flex gap-2">
                            <Button size="sm" onClick={() => review(d.id, "confirmado")}>Confirmar</Button>
                            <Button size="sm" variant="outline" onClick={() => review(d.id, "rejeitado")}>Rejeitar</Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {section === "users" && (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead>Email</TableHead><TableHead>Registado</TableHead><TableHead>Participações</TableHead></TableRow></TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell>{u.name}</TableCell>
                      <TableCell>{u.email}</TableCell>
                      <TableCell className="text-xs">{new Date(u.createdAt).toLocaleDateString("pt-AO")}</TableCell>
                      <TableCell>{u.participations?.length ?? 0}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {section === "messages" && (
          <div className="flex flex-col gap-4">
            {messages.map((m) => (
              <Card key={m.id}>
                <CardHeader><CardTitle className="text-base">{m.subject}</CardTitle></CardHeader>
                <CardContent>
                  <p className="text-sm">{m.message}</p>
                  <p className="mt-2 text-xs text-muted-foreground">{m.name} · {m.email}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {section === "logs" && (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Ação</TableHead><TableHead>Utilizador</TableHead><TableHead>Data</TableHead></TableRow></TableHeader>
                <TableBody>
                  {logs.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell className="font-mono text-xs">{l.action}</TableCell>
                      <TableCell>{l.user?.email || "—"}</TableCell>
                      <TableCell className="text-xs">{new Date(l.createdAt).toLocaleString("pt-AO")}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminShell>
  )
}
