import { redirect } from "next/navigation"
import { requireAdmin } from "@/lib/admin"
import { prisma } from "@/lib/prisma"
import AdminClient from "./admin-client"

export const dynamic = "force-dynamic"

export default async function AdminPage() {
  const admin = await requireAdmin()
  if (!admin) redirect("/entrar?next=/admin")

  const [users, deposits, participations, contactMessages, auditLogs] = await Promise.all([
    prisma.user.findMany({ orderBy: { createdAt: "desc" }, take: 50, include: { participations: true, deposits: true } }),
    prisma.deposit.findMany({ orderBy: { createdAt: "desc" }, take: 50, include: { user: true, participation: { include: { plan: true } } } }),
    prisma.participation.findMany({ orderBy: { createdAt: "desc" }, take: 50, include: { user: true, plan: true } }),
    prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" }, take: 30 }),
    prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 50, include: { user: true } }),
  ])

  return <AdminClient users={users} deposits={deposits} participations={participations} messages={contactMessages} logs={auditLogs} />
}
