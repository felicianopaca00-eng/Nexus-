import type { Metadata, Viewport } from "next"
import { Inter, JetBrains_Mono, Manrope } from "next/font/google"
import "./globals.css"
import { Toaster } from "sonner"
import { NavigationFeedback } from "@/components/navigation-feedback"
const inter=Inter({subsets:["latin"],variable:"--font-inter"}); const manrope=Manrope({subsets:["latin"],variable:"--font-manrope"}); const mono=JetBrains_Mono({subsets:["latin"],variable:"--font-jetbrains"})
export const metadata:Metadata={title:"Nexus Investments",description:"Acompanhamento de mercado e planos de participação em Kwanzas."}; export const viewport:Viewport={themeColor:"#07090F",colorScheme:"dark"}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-AO" className="bg-background"><body className={`${inter.variable} ${manrope.variable} ${mono.variable} antialiased`}><Toaster theme="dark" position="bottom-right"/><NavigationFeedback/>{children}</body></html>}
