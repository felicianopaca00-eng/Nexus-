"use client"

import { useEffect, useState } from "react"
import { usePathname } from "next/navigation"
import { LoaderCircle } from "lucide-react"

export function NavigationFeedback() {
  const [loading, setLoading] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    setLoading(false)
  }, [pathname])

  useEffect(() => {
    const handleClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null
      const clickable = target?.closest("a, button, [role='button']") as HTMLElement | null
      if (!clickable || clickable.hasAttribute("disabled") || clickable.getAttribute("aria-disabled") === "true") return
      if (clickable instanceof HTMLAnchorElement && (clickable.target === "_blank" || clickable.href.startsWith("#"))) return
      setLoading(true)
    }
    const handleSubmit = () => setLoading(true)
    document.addEventListener("click", handleClick)
    document.addEventListener("submit", handleSubmit, true)
    return () => {
      document.removeEventListener("click", handleClick)
      document.removeEventListener("submit", handleSubmit, true)
    }
  }, [])

  useEffect(() => {
    const clear = () => setLoading(false)
    window.addEventListener("pageshow", clear)
    const timer = window.setTimeout(clear, 12000)
    return () => {
      window.removeEventListener("pageshow", clear)
      window.clearTimeout(timer)
    }
  }, [loading])

  if (!loading) return null
  return <div className="pointer-events-none fixed inset-x-0 top-0 z-[100] h-1 bg-teal/20" role="status" aria-live="polite"><div className="h-full w-1/3 animate-[loading-slide_1.2s_ease-in-out_infinite] bg-teal" /><span className="sr-only">A carregar, aguarde por favor</span><div className="fixed bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-xs text-muted-foreground shadow-xl"><LoaderCircle className="size-3.5 animate-spin text-teal" />A carregar…</div></div>
}

export function LoadingButtonContent({ children, pending }: { children: React.ReactNode; pending: boolean }) {
  return pending ? <><LoaderCircle className="animate-spin" data-icon="inline-start" />A carregar…</> : children
}
