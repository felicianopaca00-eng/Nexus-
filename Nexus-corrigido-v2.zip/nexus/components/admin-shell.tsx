"use client"

import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { useState } from "react"
import {
  BarChart3,
  BriefcaseBusiness,
  ChartNoAxesCombined,
  FilePenLine,
  Gift,
  LayoutDashboard,
  LogOut,
  Menu,
  ScrollText,
  Send,
  ShieldCheck,
  Users,
  X,
  ArrowLeftRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { NexusMark } from "@/components/site-shell"
import { adminNav, riskNotice } from "@/lib/admin-data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard,
  Users,
  ArrowLeftRight,
  ChartNoAxesCombined,
  Gift,
  FilePenLine,
  Send,
  BriefcaseBusiness,
  ShieldCheck,
  ScrollText,
}

export function AdminShell({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const currentSection = searchParams.get("section") || "overview"

  const groupedNav = adminNav.reduce(
    (acc, item) => {
      const groupName = item.group
      if (!acc[groupName]) acc[groupName] = []
      acc[groupName].push(item)
      return acc
    },
    {} as Record<string, Array<(typeof adminNav)[number]>>
  )

  return (
    <div className="admin-shell min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center justify-between px-4 md:px-8">
          <Link href="/admin" className="flex items-center gap-2">
            <NexusMark small />
            <span className="font-mono text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Admin
            </span>
          </Link>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="md:hidden"
          >
            {sidebarOpen ? <X /> : <Menu />}
          </Button>

          <div className="hidden items-center gap-4 md:flex">
            <Button variant="ghost" size="icon" onClick={() => router.push("/")} title="Voltar ao site">
              <LogOut className="size-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex gap-0 md:gap-6 md:p-6">
        <aside
          className={`fixed left-0 top-16 z-30 h-[calc(100vh-4rem)] w-64 border-r border-border bg-card/50 transition-transform duration-200 md:static md:top-0 md:z-auto md:h-auto md:w-56 md:transform-none ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
          }`}
        >
          <nav className="flex flex-col gap-1 p-4 md:p-0">
            {Object.entries(groupedNav).map(([group, items]) => (
              <div key={group}>
                <p className="px-3 py-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {group}
                </p>
                {items.map((item) => {
                  const Icon = iconMap[item.icon]
                  const isActive = currentSection === item.id
                  return (
                    <Link
                      key={item.id}
                      href={`/admin?section=${item.id}`}
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center justify-between gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                        isActive
                          ? "bg-teal/10 text-teal font-medium"
                          : "text-muted-foreground hover:bg-card hover:text-foreground"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {Icon && <Icon className="size-4" />}
                        {item.label}
                      </div>
                      {"count" in item && item.count && (
                        <span className="inline-flex items-center justify-center rounded-full bg-red-500/20 px-2 py-0.5 text-xs font-medium text-red-600">
                          {item.count}
                        </span>
                      )}
                    </Link>
                  )
                })}
              </div>
            ))}
          </nav>

          <div className="absolute bottom-0 left-0 right-0 border-t border-border bg-card/80 p-4">
            <div className="text-[10px] leading-4 text-muted-foreground">{riskNotice}</div>
            <Button
              variant="outline"
              size="sm"
              className="mt-3 w-full"
              onClick={() => router.push("/")}
            >
              <LogOut className="mr-2 size-4" />
              Sair do painel
            </Button>
          </div>
        </aside>

        <main className="flex-1 overflow-hidden">{children}</main>
      </div>
    </div>
  )
}

export function AdminHeader({ title, description }: { title: string; description?: string }) {
  return (
    <div className="mb-6 md:mb-8">
      <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">NEXUS / ADMIN</p>
      <h1 className="mt-2 font-heading text-3xl font-medium text-foreground">{title}</h1>
      {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
    </div>
  )
}

export function AdminAlert({ children, variant = "warning" }: { children: React.ReactNode; variant?: "info" | "warning" | "error" }) {
  const bgClass = {
    info: "bg-blue-500/10 border-blue-200 text-blue-700",
    warning: "bg-amber-500/10 border-amber-200 text-amber-700",
    error: "bg-red-500/10 border-red-200 text-red-700",
  }[variant]

  return (
    <div className={`rounded-md border p-4 text-sm ${bgClass}`}>
      {children}
    </div>
  )
}
