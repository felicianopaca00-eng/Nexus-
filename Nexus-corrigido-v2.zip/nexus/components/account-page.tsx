import Link from "next/link"
import { ArrowRight, Bell, CircleHelp, FileText, Gift, Settings, Trophy, Wallet } from "lucide-react"
import { Header, UserBottomNav, SectionIntro } from "@/components/site-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { requireSession } from "@/lib/auth"

const pageData = {
  extrato: { eyebrow: "NEXUS / EXTRATO", title: "Histórico e extrato", description: "Consulte todas as movimentações da sua conta.", icon: FileText, items: ["Depósitos", "Investimentos", "Rendimentos", "Saques"] },
  indicacoes: { eyebrow: "NEXUS / INDICAÇÕES", title: "Indicações e missões", description: "Acompanhe convites, comissões e recompensas.", icon: Gift, items: ["Link de indicação", "Convidados", "Comissões", "Missões"] },
  notificacoes: { eyebrow: "NEXUS / NOTIFICAÇÕES", title: "Central de notificações", description: "Mantenha-se informado sobre a sua atividade.", icon: Bell, items: ["Atualizações da conta", "Investimentos", "Depósitos e saques", "Preferências de alerta"] },
  suporte: { eyebrow: "NEXUS / SUPORTE", title: "Suporte e FAQ", description: "Encontre respostas ou fale com a nossa equipa.", icon: CircleHelp, items: ["Perguntas frequentes", "Abrir ticket", "Histórico de atendimentos", "Contactar suporte"] },
  carteira: { eyebrow: "NEXUS / CARTEIRA", title: "Carteira", description: "Veja saldos, moedas e comissões num só lugar.", icon: Wallet, items: ["Saldo disponível", "Saldo investido", "Bónus", "Comissões"] },
  configuracoes: { eyebrow: "NEXUS / CONFIGURAÇÕES", title: "Configurações", description: "Personalize a sua experiência e segurança.", icon: Settings, items: ["Preferências", "Notificações", "Privacidade e segurança", "Apagar conta"] },
  termos: { eyebrow: "NEXUS / TERMOS", title: "Termos e políticas", description: "Consulte os documentos legais da Nexus Investments.", icon: FileText, items: ["Termos e condições", "Política de privacidade", "Política de cookies", "Histórico de aceitação"] },
  ranking: { eyebrow: "NEXUS / RANKING", title: "Ranking e conquistas", description: "Acompanhe o seu nível e as conquistas desbloqueadas.", icon: Trophy, items: ["Nível atual", "Ranking de investidores", "Conquistas", "Próximas recompensas"] },
} as const

const itemLinks: Record<string, string> = {
  "Termos e condições": "/termos",
  "Política de privacidade": "/privacidade",
  "Política de cookies": "/privacidade",
  "Histórico de aceitação": "/termos",
  "Depósitos": "/depositar",
  "Investimentos": "/planos",
  "Perguntas frequentes": "/sobre",
  "Privacidade e segurança": "/perfil",
  "Preferências": "/configuracoes",
  "Notificações": "/notificacoes",
  "Saldo disponível": "/carteira",
  "Saldo investido": "/painel",
  "Link de indicação": "/indicacoes",
  "Comissões": "/carteira",
  "Atualizações da conta": "/notificacoes",
  "Depósitos e saques": "/extrato",
  "Preferências de alerta": "/configuracoes",
  "Contactar suporte": "/suporte",
}

export async function AccountPage({ type }: { type: keyof typeof pageData }) {
  const session = await requireSession()
  const data = pageData[type]
  const Icon = data.icon
  return <><Header /><main className="page-wrap pb-28"><div className="container"><SectionIntro eyebrow={data.eyebrow} title={data.title}>{data.description}</SectionIntro><div className="mt-10 grid gap-4 md:grid-cols-2"><Card className="border-primary/40 bg-card/70 md:col-span-2"><CardHeader><div className="flex items-center gap-3"><Icon className="text-champagne" /><div><CardTitle>{session.user.name}</CardTitle><p className="mt-1 text-sm text-muted-foreground">Área pessoal · informação protegida</p></div><Badge className="ml-auto" variant="secondary">Conta ativa</Badge></div></CardHeader></Card>{data.items.map((item, index) => <Card key={item}><CardHeader><CardTitle className="text-lg">{item}</CardTitle></CardHeader><CardContent><p className="text-sm leading-6 text-muted-foreground">Consulte e gira esta área da sua conta com segurança.</p><Button asChild variant="outline" className="mt-5"><Link href={itemLinks[item] ?? "/painel"}>Abrir <ArrowRight data-icon="inline-end" /></Link></Button></CardContent></Card>)}</div></div></main><UserBottomNav /></>
}

export function AccountRoute({ type }: { type: keyof typeof pageData }) { return <AccountPage type={type} /> }
