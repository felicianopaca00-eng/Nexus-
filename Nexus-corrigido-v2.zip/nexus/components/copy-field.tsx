"use client"

import { Copy } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"

export function CopyField({ label, value }: { label: string; value: string }) {
  return <div className="flex items-center justify-between gap-4 border-b border-border py-4"><div><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 break-all font-mono text-sm text-foreground">{value}</p></div><Button variant="ghost" size="icon" onClick={() => { navigator.clipboard?.writeText(value); toast.success("Copiado para a área de transferência") }} aria-label={`Copiar ${label}`}><Copy /></Button></div>
}
