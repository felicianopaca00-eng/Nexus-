export const planSeed=[
{id:"start",name:"Nexo Start",minimum:30000,horizonDays:30,included:["Acesso ao acompanhamento de mercado","Atualizações do ciclo"],excluded:["Garantia de capital","Rendimento fixo"]},
{id:"core",name:"Nexo Core",minimum:90000,horizonDays:60,included:["Acesso ao acompanhamento de mercado","Atualizações do ciclo","Leitura de contexto"],excluded:["Garantia de capital","Rendimento fixo"]},
{id:"prime",name:"Nexo Prime",minimum:250000,horizonDays:90,included:["Acesso ao acompanhamento de mercado","Atualizações do ciclo","Leitura de contexto aprofundada"],excluded:["Garantia de capital","Rendimento fixo"]},
]
export const formatAOA=(n:number)=>new Intl.NumberFormat("pt-AO",{style:"currency",currency:"AOA",maximumFractionDigits:0}).format(n)
