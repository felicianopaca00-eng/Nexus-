import { z } from "zod"
export const registerSchema=z.object({name:z.string().trim().min(2,"Indique o seu nome."),email:z.string().trim().email("Indique um email válido."),password:z.string().min(8,"A palavra-passe deve ter pelo menos 8 caracteres."),confirmation:z.string()}).refine(v=>v.password===v.confirmation,{path:["confirmation"],message:"As palavras-passe não coincidem."})
export const loginSchema=z.object({email:z.string().trim().email("Indique um email válido."),password:z.string().min(1,"Indique a palavra-passe.")})
export const contactSchema=z.object({name:z.string().trim().min(2),email:z.string().trim().email(),subject:z.string().trim().min(2),message:z.string().trim().min(10)})
