export type AdminStatus = "Activo" | "Suspenso" | "Pendente" | "Em análise" | "Aprovado" | "Rejeitado" | "Processando" | "Concluído"

export const adminUsers = [
  { id: "NX-1042", name: "Marta Joaquim", email: "marta.joaquim@email.ao", phone: "+244 923 410 228", registered: "12 Jun 2026", balance: 184500, invested: 250000, referrals: 8, status: "Activo" as AdminStatus, activity: "Hoje, 09:42" },
  { id: "NX-1041", name: "Carlos Manuel", email: "carlos.manuel@email.ao", phone: "+244 928 771 090", registered: "10 Jun 2026", balance: 72000, invested: 90000, referrals: 3, status: "Activo" as AdminStatus, activity: "Ontem, 18:21" },
  { id: "NX-1040", name: "Ana Paulo", email: "ana.paulo@email.ao", phone: "+244 934 992 100", registered: "08 Jun 2026", balance: 0, invested: 0, referrals: 0, status: "Pendente" as AdminStatus, activity: "08 Jun 2026" },
  { id: "NX-1039", name: "Domingos Silva", email: "domingos.silva@email.ao", phone: "+244 922 114 035", registered: "04 Jun 2026", balance: 32000, invested: 30000, referrals: 1, status: "Suspenso" as AdminStatus, activity: "04 Jun 2026" },
  { id: "NX-1038", name: "Lídia António", email: "lidia.antonio@email.ao", phone: "+244 925 603 442", registered: "01 Jun 2026", balance: 450000, invested: 250000, referrals: 12, status: "Activo" as AdminStatus, activity: "Hoje, 07:16" },
]

export const adminRequests = [
  { id: "DEP-8821", user: "Marta Joaquim", type: "Depósito", method: "Multicaixa", amount: 250000, status: "Pendente" as AdminStatus, date: "Hoje, 09:40" },
  { id: "SAQ-4410", user: "Carlos Manuel", type: "Saque", method: "KWiK", amount: 18000, status: "Em análise" as AdminStatus, date: "Hoje, 08:12" },
  { id: "DEP-8818", user: "Lídia António", type: "Depósito", method: "Transferência", amount: 90000, status: "Concluído" as AdminStatus, date: "Ontem, 16:30" },
  { id: "SAQ-4408", user: "Domingos Silva", type: "Saque", method: "Multicaixa", amount: 12000, status: "Rejeitado" as AdminStatus, date: "Ontem, 11:04" },
  { id: "DEP-8812", user: "Pedro André", type: "Depósito", method: "KWiK", amount: 30000, status: "Processando" as AdminStatus, date: "18 Jun 2026" },
]

export const adminJobs = [
  { id: "JOB-01", title: "Analista de mercado", type: "Tempo inteiro", applicants: 14, deadline: "30 Jun 2026", status: "Activa" },
  { id: "JOB-02", title: "Especialista de suporte", type: "Híbrido", applicants: 8, deadline: "05 Jul 2026", status: "Activa" },
  { id: "JOB-03", title: "Assistente de operações", type: "Estágio", applicants: 21, deadline: "12 Jun 2026", status: "Fechada" },
]

export const adminNav = [
  { id: "overview", label: "Visão geral", group: "Operação", icon: "LayoutDashboard" },
  { id: "users", label: "Utilizadores", group: "Operação", icon: "Users" },
  { id: "requests", label: "Depósitos e saques", group: "Operação", icon: "ArrowLeftRight", count: 3 },
  { id: "capital", label: "Capital e performance", group: "Financeiro", icon: "ChartNoAxesCombined" },
  { id: "bonuses", label: "Comissões e bónus", group: "Financeiro", icon: "Gift" },
  { id: "content", label: "Conteúdo", group: "Comunicação", icon: "FilePenLine" },
  { id: "notifications", label: "Notificações", group: "Comunicação", icon: "Send" },
  { id: "jobs", label: "Vagas e candidaturas", group: "Pessoas", icon: "BriefcaseBusiness" },
  { id: "security", label: "Segurança e sessões", group: "Sistema", icon: "ShieldCheck" },
  { id: "logs", label: "Logs de acesso", group: "Sistema", icon: "ScrollText" },
] as const

export const adminChart = [
  { day: "12 Jun", value: 11800000 }, { day: "13 Jun", value: 12100000 }, { day: "14 Jun", value: 11950000 }, { day: "15 Jun", value: 12600000 }, { day: "16 Jun", value: 13050000 }, { day: "17 Jun", value: 12900000 }, { day: "18 Jun", value: 13600000 }, { day: "19 Jun", value: 14200000 },
]

export const adminLogs = [
  { user: "Marta Joaquim", event: "Sessão iniciada", ip: "197.149.22.18", date: "Hoje, 09:42", result: "Sucesso" },
  { user: "Carlos Manuel", event: "Tentativa de acesso", ip: "41.78.11.92", date: "Hoje, 08:16", result: "Falhou" },
  { user: "Lídia António", event: "Sessão iniciada", ip: "102.23.140.7", date: "Hoje, 07:16", result: "Sucesso" },
]

export const formatAdminAOA = (value: number) => new Intl.NumberFormat("pt-AO", { style: "currency", currency: "AOA", maximumFractionDigits: 0 }).format(value)

export const statusClass = (status: string) => {
  if (["Activo", "Aprovado", "Concluído", "Sucesso", "Activa"].includes(status)) return "status-positive"
  if (["Suspenso", "Rejeitado", "Falhou", "Fechada"].includes(status)) return "status-negative"
  return "status-pending"
}

export const riskNotice = "Ambiente de demonstração. Ações administrativas não alteram dados reais, pagamentos, custódia ou sessões."
