const resendKey = process.env.RESEND_API_KEY
const from = process.env.EMAIL_FROM || "Nexus Investments <suporte@nexusinvestments.ao>"
const appUrl = process.env.APP_URL || "http://localhost:3000"

export async function sendEmail(to: string, subject: string, html: string) {
  if (!resendKey) {
    console.warn("[email] RESEND_API_KEY não configurada —", subject, to)
    return { ok: false as const, reason: "no-key" }
  }
  // Dynamic import to avoid build issues if package not present yet
  try {
    const { Resend } = await import("resend")
    const resend = new Resend(resendKey)
    const { error } = await resend.emails.send({ from, to, subject, html })
    if (error) {
      console.error("[email]", error)
      return { ok: false as const, reason: "error" }
    }
    return { ok: true as const }
  } catch (e) {
    console.error("[email] import/send failed", e)
    return { ok: false as const, reason: "error" }
  }
}

export function passwordResetEmail(name: string, token: string) {
  const link = `${appUrl}/recuperar?token=${token}`
  const html = `<div style="font-family:Georgia,serif;background:#0b0f14;color:#e8edf2;padding:32px"><h1 style="color:#2dd4bf;letter-spacing:0.2em;font-size:14px">NEXUS INVESTMENTS</h1><p>Olá, ${name}.</p><p>Recebemos um pedido para redefinir a tua palavra-passe. O link expira em 30 minutos.</p><p><a href="${link}" style="background:#2dd4bf;color:#0b0f14;padding:12px 20px;border-radius:6px;text-decoration:none;font-weight:bold">Redefinir palavra-passe</a></p><p style="color:#8a93a0;font-size:12px">Se não foste tu, ignora este email. Nunca partilhes códigos, PIN ou seed phrase.</p></div>`
  return { subject: "Redefinição de palavra-passe — Nexus Investments", html }
}

export function depositReceivedEmail(name: string, amount: string, plan: string) {
  const html = `<div style="font-family:Georgia,serif;background:#0b0f14;color:#e8edf2;padding:32px"><h1 style="color:#2dd4bf;letter-spacing:0.2em;font-size:14px">NEXUS INVESTMENTS</h1><p>Olá, ${name}.</p><p>Recebemos o teu comprovativo de depósito de <b>${amount}</b> no plano <b>${plan}</b>.</p><p>A confirmação só acontece depois de reconciliação. Acompanha o estado no painel.</p><p style="color:#8a93a0;font-size:12px">Nunca pedimos PIN, OTP, SMS ou seed phrase.</p></div>`
  return { subject: "Depósito recebido — Nexus Investments", html }
}

export function depositStatusEmail(name: string, amount: string, status: "confirmado" | "rejeitado", note?: string) {
  const label = status === "confirmado" ? "confirmado" : "rejeitado"
  const html = `<div style="font-family:Georgia,serif;background:#0b0f14;color:#e8edf2;padding:32px"><h1 style="color:#2dd4bf;letter-spacing:0.2em;font-size:14px">NEXUS INVESTMENTS</h1><p>Olá, ${name}.</p><p>O teu depósito de <b>${amount}</b> foi <b>${label}</b>.</p>${note ? `<p>${note}</p>` : ""}<p><a href="${appUrl}/painel" style="color:#2dd4bf">Ver painel</a></p></div>`
  return { subject: `Depósito ${label} — Nexus Investments`, html }
}
