export const brand = { name: "NEXUS", descriptor: "INVESTMENTS", fullName: "Nexus Investments" }

export const plans = [
  { id: "start", name: "Nexo Start", minimum: 30000, horizon: "30 dias", tone: "teal", included: ["Acompanhamento de mercado", "Painel de posição", "Relatórios de ciclo"], excluded: ["Rendimento fixo", "Garantia de capital"] },
  { id: "core", name: "Nexo Core", minimum: 90000, horizon: "60 dias", tone: "champagne", included: ["Acompanhamento de mercado", "Painel de posição", "Relatórios de ciclo", "Leituras de contexto"], excluded: ["Rendimento fixo", "Garantia de capital"] },
  { id: "prime", name: "Nexo Prime", minimum: 250000, horizon: "90 dias", tone: "teal", included: ["Acompanhamento de mercado", "Painel de posição", "Relatórios de ciclo", "Leituras de contexto", "Resumo prioritário"], excluded: ["Rendimento fixo", "Garantia de capital"] },
]

export const payments = { multicaixa: { entidade: process.env.PAYMENT_ENTITY || "", referencia: process.env.PAYMENT_ENTITY ? "Gerada por depósito" : "" }, kwik: { iban: process.env.PAYMENT_IBAN_KWIK || "" }, mozambique: "+258 85 273 5182" }
export const riskText = "Criptoactivos são voláteis. Pode perder a totalidade do valor. Isto não constitui aconselhamento financeiro nem oferta pública de valores. Rendimentos passados não predizem rendimentos futuros. Operações de captação de aforro do público podem exigir licenciamento."

export const marketData = [
  { name: "09:00", btc: 11240000, eth: 580000, usdt: 920 }, { name: "11:00", btc: 11285000, eth: 584000, usdt: 921 }, { name: "13:00", btc: 11220000, eth: 579000, usdt: 920 }, { name: "15:00", btc: 11310000, eth: 586000, usdt: 922 }, { name: "17:00", btc: 11352000, eth: 590000, usdt: 923 }, { name: "19:00", btc: 11328000, eth: 588000, usdt: 922 }, { name: "21:00", btc: 11388000, eth: 593000, usdt: 924 },
]
export const formatAOA = (value: number) => new Intl.NumberFormat("pt-AO", { style: "currency", currency: "AOA", maximumFractionDigits: 0 }).format(value)
export const formatMZN = (value: number) => new Intl.NumberFormat("pt-MZ", { style: "currency", currency: "MZN", maximumFractionDigits: 0 }).format(value)
export const aoaToMzn = (value: number) => value * Number(process.env.FX_AOA_MZN || "0.36")
