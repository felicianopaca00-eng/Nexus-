import { prisma } from "@/lib/prisma"

export async function auditLog(params: {
  userId?: string | null
  action: string
  entity?: string
  entityId?: string
  meta?: Record<string, unknown>
  ip?: string | null
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId ?? null,
        action: params.action,
        entity: params.entity ?? null,
        entityId: params.entityId ?? null,
        meta: params.meta as any,
        ip: params.ip ?? null,
      },
    })
  } catch (e) {
    console.error("[audit]", e)
  }
}
