import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { randomBytes, createHash } from "crypto"
import bcrypt from "bcryptjs"
import { prisma } from "@/lib/prisma"

const COOKIE = "nexus_session"
export async function createSession(userId: string) { const token = randomBytes(32).toString("hex"); await prisma.session.create({data:{token,userId,expiresAt:new Date(Date.now()+1000*60*60*24*30)}}); (await cookies()).set(COOKIE, token, {httpOnly:true,secure:true,sameSite:"lax",path:"/",maxAge:60*60*24*30}); return token }
export async function getSession() { const token=(await cookies()).get(COOKIE)?.value; if(!token)return null; const session=await prisma.session.findUnique({where:{token},include:{user:true}}); if(!session||session.revokedAt||session.expiresAt<new Date())return null; return session }
export async function requireSession() { const session=await getSession(); if(!session) redirect(`/entrar?next=${encodeURIComponent("/painel")}`); return session }
export async function revokeSession() { const token=(await cookies()).get(COOKIE)?.value; if(token) await prisma.session.updateMany({where:{token},data:{revokedAt:new Date()}}); (await cookies()).delete(COOKIE) }
export async function hashPassword(password:string){return bcrypt.hash(password,12)}
export async function verifyPassword(password:string,hash:string){return bcrypt.compare(password,hash)}
export function resetHash(token:string){return createHash("sha256").update(token).digest("hex")}
