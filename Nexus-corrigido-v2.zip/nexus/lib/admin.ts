import { getSession } from "@/lib/auth"

export function getAdminEmails(): string[] {
  return (process.env.ADMIN_EMAILS || "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean)
}

export async function requireAdmin() {
  const session = await getSession()
  if (!session) return null
  const admins = getAdminEmails()
  if (admins.length === 0) return null
  if (!admins.includes(session.user.email.toLowerCase())) return null
  return session
}
