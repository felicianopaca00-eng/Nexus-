import { NextRequest, NextResponse } from "next/server"

const publicPaths = ["/", "/entrar", "/registar", "/recuperar", "/planos", "/mercados", "/sobre", "/termos", "/privacidade", "/riscos", "/contacto", "/api", "/_next", "/favicon.ico"]

export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname
  if (publicPaths.some((prefix) => path === prefix || path.startsWith(`${prefix}/`))) {
    return NextResponse.next()
  }
  if (!request.cookies.get("nexus_session")) {
    return NextResponse.redirect(new URL(`/entrar?next=${encodeURIComponent(`${path}${request.nextUrl.search}`)}`, request.url))
  }
  return NextResponse.next()
}

export const config = { matcher: ["/:path*"] }
