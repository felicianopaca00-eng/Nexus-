# Nexus Investments

Plataforma de participação de mercado em Kwanzas.

## Setup

1. `cp .env.example .env.local` e preenche.
2. `pnpm install`
3. `pnpm db:push`
4. `pnpm db:seed`
5. `pnpm dev`

## Notas

- `/admin` só é acessível a emails listados em `ADMIN_EMAILS`.
- Sem `RESEND_API_KEY`, emails são apenas logados.
- Dados de pagamento e operador legal vêm de variáveis de ambiente.
- Confirma licenciamento junto do BNA antes de aceitar fundos do público.
